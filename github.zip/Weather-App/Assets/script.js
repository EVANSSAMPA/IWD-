$(window).on("load", function () {
  currentLocation();
  checkLocalStorage();
  startUpdatingTime();
});

// API Key for all weather data
var APIKey = "09e0d7e534e41ce68ba5f2577fa5f760";
var q = "";
var now = moment();

// Date and time format for header
function startUpdatingTime() {
  setInterval(function () {
    // Get the current date and time including seconds
    var currentDate = moment().format("Do MMMM YYYY || h:mm:ss a");

    // Update the text content of the HTML element with the current time
    $("#currentDay").text(currentDate);
  }, 1000); // Update every second
}

// Setting the click function at ID search button
// Flag variable to track if checkLocalStorage() has run
let hasCheckedLocalStorage = false;

$("#search-button").on("click", function (event) {
  // Preventing the button from trying to submit the form
  event.preventDefault();

  let q = $("#city-input").val();
  if (q === "") {
    return alert("Please Enter a Valid City Name!");
  }
  getWeather(q);
  saveToLocalStorage(q);

  $("#city-input").val(""); // Clear the input field

  // Check if checkLocalStorage() has already been called
  if (!hasCheckedLocalStorage) {
    $("#historyList").empty();
    checkLocalStorage();
    // Set the flag to true so it won't be called again
    hasCheckedLocalStorage = true;
  }
});

// Function to create Button for searched city
function createRecentSearchBtn(q) {
  var newLi = $("<li>");
  var newBtn = $("<button>");
  // Adding Extra ID for Button to stop Creating Duplicate Button on Click
  newBtn.attr("id", "extraBtn");
  newBtn.addClass("button is-small recentSearch");
  newBtn.text(q);
  newLi.append(newBtn);
  $("#historyList").prepend(newLi);
  // Setting click function to prevent duplicate button
  $("#extraBtn").on("click", function () {
    var newQ = $(this).text();
    getWeather(newQ);
  });
}

// Converting temperature F to Celsius
function convertToC(fahrenheit) {
  var fTempVal = fahrenheit;
  var cTempVal = (fTempVal - 32) * (5 / 9);
  var celcius = Math.round(cTempVal * 10) / 10;
  return celcius;
}

// Function to get weather details
function getWeather(q) {
  var queryURL =
    "https://api.openweathermap.org/data/2.5/weather?q=" +
    q +
    "&units=imperial&appid=" +
    APIKey;

  $.ajax({
    url: queryURL,
    method: "GET",
    error: (err) => {
      alert(
        "Your city was not found. Check your spelling or enter a valid city name."
      );
      return;
    },
  }).then(function (response) {
    console.log(response);

    // Extract the time zone offset from the API response
    var timezoneOffset = response.timezone;

    // Convert the current UTC time to the city's local time
    var cityTime = moment
      .utc()
      .utcOffset(timezoneOffset / 60)
      .format("MMMM Do YYYY || h:mm a");

    // Empty the city list to avoid duplication
    $(".cityList").empty();
    $("#days").empty();

    var celcius = convertToC(response.main.temp);
    var cityMain1 = $("<div>").append(
      $("<p><h2>" + response.name + " (" + cityTime + ")" + "</h2><p>")
    );
    var image = $('<img class="imgsize">').attr(
      "src",
      "http://openweathermap.org/img/w/" + response.weather[0].icon + ".png"
    );
    var degreeMain = $("<p>").text(
      "Temperature : " + response.main.temp + " °F (" + celcius + "°C)"
    );
    var humidityMain = $("<p>").text(
      "Humidity : " + response.main.humidity + "%"
    );
    var windMain = $("<p>").text("Wind Speed : " + response.wind.speed + "MPH");
    var uvIndexcoord =
      "&lat=" + response.coord.lat + "&lon=" + response.coord.lon;
    var cityId = response.id;

    displayUVindex(uvIndexcoord);
    displayForecast(cityId);

    cityMain1
      .append(image)
      .append(degreeMain)
      .append(humidityMain)
      .append(windMain);
    $("#cityList").empty();
    $("#cityList").append(cityMain1);
  });
}

// Function for UV Index
function displayUVindex(uv) {
  $.ajax({
    // Gets the UV index info
    url: "https://api.openweathermap.org/data/2.5/uvi?appid=" + APIKey + uv,
    method: "GET",
  }).then(function (response) {
    var UVIndex = $("<p><span>");
    UVIndex.attr("class", "badge badge-danger");
    UVIndex.text(response.value);
    $("#cityList").append("UV-Index : ").append(UVIndex);
  });
}

// Function to Display 5 Day forecast
function displayForecast(c) {
  $.ajax({
    // Gets the 5-day forecast API
    url:
      "https://api.openweathermap.org/data/2.5/forecast?id=" +
      c +
      "&units=imperial&APPID=" +
      APIKey,
    method: "GET",
  }).then(function (response) {
    var arrayList = response.list;
    for (var i = 0; i < arrayList.length; i++) {
      if (arrayList[i].dt_txt.split(" ")[1] === "12:00:00") {
        var celcius = convertToC(arrayList[i].main.temp); // Converting F to Celsius
        var cityMain = $("<div>");
        cityMain.addClass(
          "col forecast bg-primary text-white ml-3 mb-3 rounded>"
        );
        var date5 = $("<h5>").text(response.list[i].dt_txt.split(" ")[0]);
        var image = $("<img>").attr(
          "src",
          "http://openweathermap.org/img/w/" +
            arrayList[i].weather[0].icon +
            ".png"
        );
        var degreeMain = $("<p>").text(
          "Temp : " + arrayList[i].main.temp + " °F (" + celcius + "°C)"
        );
        var humidityMain = $("<p>").text(
          "Humidity : " + arrayList[i].main.humidity + "%"
        );
        var windMain = $("<p>").text(
          "Wind Speed : " + arrayList[i].wind.speed + "MPH"
        );
        cityMain
          .append(date5)
          .append(image)
          .append(degreeMain)
          .append(humidityMain)
          .append(windMain);
        $("#days").append(cityMain);
      }
    }
  });
}

// Display automatic Current Location or Default to Lusaka
function currentLocation() {
  $.ajax({
    url: "https://freegeoip.app/json/",
    method: "GET",
  })
    .then(function (response) {
      q = response.city || "Lusaka";
      getWeather(q);
    })
    .fail(function () {
      // If geolocation fails, default to Lusaka
      getWeather("Lusaka");
    });
}

// Function to get data from Local Storage
function checkLocalStorage() {
  var storedData = localStorage.getItem("queries");
  var dataArray = [];
  if (!storedData) {
    console.log("no data stored");
  } else {
    storedData.trim();
    dataArray = storedData.split(",");
    for (var i = 0; i < dataArray.length; i++) {
      createRecentSearchBtn(dataArray[i]);
    }
  }
}

// Function to Set data in Local storage
function saveToLocalStorage(q) {
  var data = localStorage.getItem("queries");
  if (data) {
    console.log(data, q);
  } else {
    data = q;
    localStorage.setItem("queries", data);
  }
  if (data.indexOf(q) === -1) {
    data = data + "," + q;
    localStorage.setItem("queries", data);
    createRecentSearchBtn(q);
  }
}

// To remove from localStorage
function removeStorage() {
  localStorage.removeItem("queries");
}

// Clear history function to clear searched city list
$("#clear-history").on("click", function () {
  $("#historyList").empty();
  removeStorage();
});

// For footer date with copyright
var footerDate = new Date().getFullYear();
$("#footer-text").text(footerDate);
